/**********************************
ITAR Web Validation Scripts
Created 9/25/08
By Ken Courville
For Implementation of ITAR field

Instructions:
- Create a link to this javascript file
- Ensure ITAR radio buttons are defined with id's of "itarYes" and "itarNo".
- Create a hidden field with the id of "itarPreviousValue" which contains the value of ITAR 
when the page was initially loaded (not on postback).
- Add onclick="return onRadioItar_Change(this);" as an attribute for each radio button.
- Add "return validateItar();" to other the proper submit button or the form.submit event to enforce validation.
- If possible, also enforce validation on server side!

Sample html setup:
ITAR?
<input id="itarPreviousValue" name="itarPreviousValue" type="hidden" value="true" />
<input id="itarYes" name="radioItar" type="radio" value="Yes" checked="checked" onclick="return onRadioItar_Change(this);" />Yes
<input id="itarNo" name="radioItar" type="radio" value="No" onclick="return onRadioItar_Change(this);" />No</p>
<input id="Button1" type="submit" value="Submit" onclick="return validateItar();" />

Sample ASP.NET markup:
<asp:Label ID="Label1" runat="server" Text="ITAR?"></asp:Label>
<asp:RadioButton ID="itarYes" runat="server" GroupName="radioITAR" Text="Yes" onclick="return onRadioItar_Change(this);" />
<asp:RadioButton ID="itarNo" runat="server" GroupName="radioITAR" Text="No" Checked="true"
onclick="return onRadioItar_Change(this);" />
<asp:HiddenField ID="itarPreviousValue" runat="server" Value="no" />
<br />
<br />
<asp:Button ID="Button1" runat="server" Text="Button" OnClientClick="return validateItar();" />
    
Refer to the sample html files as needed.
    
*/

function onRadioItar_Change( obj ) {
  // Allow for some variation of "true" and "false" values
  // any other value will translate to "ITAR is not specified"  
  var tmpPreviousValue = document.getElementById("itarPreviousValue").value;
  var itarPreviousValue = null;
  if (tmpPreviousValue.toLowerCase() == "true" || tmpPreviousValue == "1" || tmpPreviousValue == "-1" || tmpPreviousValue.toLowerCase() == "yes") {
    itarPreviousValue = true;
  } else
    if (tmpPreviousValue.toLowerCase() == "false" || tmpPreviousValue == "0" || tmpPreviousValue.toLowerCase() == "no") {
    itarPreviousValue = false;
  }

  // Reference ITAR radio buttons
  var radioYesChecked = document.getElementById("itarYes").checked;
  var radioNoChecked = document.getElementById("itarNo").checked;
  
  // Business rules checked here
  if (itarPreviousValue != null) {
    if (itarPreviousValue == true && radioNoChecked) { // Changing Yes to No
      alert("To change ITAR status; please contact your sales person at 1-800-979-4722 after placing this order.");
      document.getElementById("itarYes").checked = true;
      document.getElementById("itarNo").checked = false;
    }
  } else {
    return true;
  }
} // onRadioItar_Change()

function validateItar() {
  // Reference ITAR radio buttons
  var radioYesChecked = document.getElementById("itarYes").checked;
  var radioNoChecked = document.getElementById("itarNo").checked;

  if (!(radioYesChecked || radioNoChecked)) {
    alert(
              "Please indicate whether or not your board design data is ITAR-controlled.\n\n" +
              "ITAR is the U.S. Government's \"International Traffic in Arms Regulations\"\n" +
              "which controls the export of aerospace and defense equipment from the U.S.\n" +
              "Go to http://pmdtc.state.gov/itar_index.htm for more information."
         );
    var itar = document.getElementById("itarNo");
    itar.focus();
    return false;
  } else {
    return true;
  }
} // validateItar()        