% clear all;
clc;

load('butt_band_pass')
load('cheb_low_pass')
% load('good');

% s=good(:,2);
% t=good(:,1);

figure;
p=filtfilt(num,den,s);
p2=filtfilt(num1,den1,p);
plot(t,p2);
hold on;
plot(t,s,'r');
% legend('Filtered','Original');
xlabel('Time:s');
ylabel('Voltage:V');
