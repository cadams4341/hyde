clear all;
clc;

% load('s');
% load('s1');
% load('s2');
% load('s3');
load('good')

s=good(:,2);
t=good(:,1);

fs=1000;
wp=[0.9,50]/(fs/2);
ws=[0.1,200]/(fs/2);
rp=0.5;
rs=40;
[N,wc]=buttord(wp,ws,rp,rs);
[num,den]=butter(N,wc);
[H,W]=freqz(num,den);
% plot(fs*W/(2*pi),abs(H));
% figure;
p=filtfilt(1.5*num,den,s);
plot(t,p);
hold on;
plot(t,s,'r');
% hold on;
% plot(s0,'--g');
% plot(offset,'--r');